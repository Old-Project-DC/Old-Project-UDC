# Cronómetro
Cronometro con minutos y segundos

<img src="https://i.ibb.co/MSnHGqt/Screen-Shot-2021-04-27-at-08-21-06.png" alt="crono" width="400"/>

**App desarrollada en este tutorial:** https://youtu.be/kqMUFJp7K24

Tecnologías:
- HTML
- CSS
- JavaScript
